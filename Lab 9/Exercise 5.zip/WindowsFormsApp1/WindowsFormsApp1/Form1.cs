﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void AddButton_Click(object sender, EventArgs e)
        {
            double d1, d2;
            bool valid = true;
            if (double.TryParse(FirstNumberTextBox.Text, out d1) == false || d1 <= 0)
            {
                valid = false;
            }
            if (double.TryParse(SecondNumberTextBox.Text, out d2) == false || d2 <= 0)
            {
                valid = false;
            }
            if (valid == false)
            {
                ResultsLabel.ForeColor = Color.Red;
                ResultsLabel.Text = "Values must be numeric and > 0";
            }
            else
            {
                ResultsLabel.ForeColor = Color.Yellow;
                ResultsLabel.Text = $"{d1} + {d2} = {d1 + d2}";
            }
        }

        private void MultiplyButton_Click(object sender, EventArgs e)
        {
            double d1, d2;
            bool valid = true;
            if (double.TryParse(FirstNumberTextBox.Text, out d1) == false || d1 <= 0)
            {
                valid = false;
            }
            if (double.TryParse(SecondNumberTextBox.Text, out d2) == false || d2 <= 0)
            {
                valid = false;
            }
            if (valid == false)
            {
                ResultsLabel.ForeColor = Color.Red;
                ResultsLabel.Text = "Values must be numeric and > 0";
            }
            else
            {
                ResultsLabel.ForeColor = Color.Yellow;
                ResultsLabel.Text = $"{d1} * {d2} = {d1 * d2}";
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            FirstNumberTextBox.Text = "";
            SecondNumberTextBox.Text = "";
        }
    }
}
