﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstNumberLabel = new System.Windows.Forms.Label();
            this.FirstNumberTextBox = new System.Windows.Forms.TextBox();
            this.CongratulationsLabel = new System.Windows.Forms.Label();
            this.SimpleCalculatorLabel = new System.Windows.Forms.Label();
            this.SecondNumberLabel = new System.Windows.Forms.Label();
            this.SecondNumberTextBox = new System.Windows.Forms.TextBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.MultiplyButton = new System.Windows.Forms.Button();
            this.ResultsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FirstNumberLabel
            // 
            this.FirstNumberLabel.AutoSize = true;
            this.FirstNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNumberLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FirstNumberLabel.Location = new System.Drawing.Point(105, 95);
            this.FirstNumberLabel.Name = "FirstNumberLabel";
            this.FirstNumberLabel.Size = new System.Drawing.Size(171, 31);
            this.FirstNumberLabel.TabIndex = 0;
            this.FirstNumberLabel.Text = "First Number";
            this.FirstNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FirstNumberTextBox
            // 
            this.FirstNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNumberTextBox.Location = new System.Drawing.Point(275, 95);
            this.FirstNumberTextBox.Name = "FirstNumberTextBox";
            this.FirstNumberTextBox.Size = new System.Drawing.Size(426, 31);
            this.FirstNumberTextBox.TabIndex = 1;
            this.FirstNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // CongratulationsLabel
            // 
            this.CongratulationsLabel.Location = new System.Drawing.Point(0, 0);
            this.CongratulationsLabel.Name = "CongratulationsLabel";
            this.CongratulationsLabel.Size = new System.Drawing.Size(100, 23);
            this.CongratulationsLabel.TabIndex = 0;
            // 
            // SimpleCalculatorLabel
            // 
            this.SimpleCalculatorLabel.AutoSize = true;
            this.SimpleCalculatorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SimpleCalculatorLabel.Location = new System.Drawing.Point(247, 9);
            this.SimpleCalculatorLabel.Name = "SimpleCalculatorLabel";
            this.SimpleCalculatorLabel.Size = new System.Drawing.Size(306, 31);
            this.SimpleCalculatorLabel.TabIndex = 4;
            this.SimpleCalculatorLabel.Text = "SimpleCalculatorLabel";
            // 
            // SecondNumberLabel
            // 
            this.SecondNumberLabel.AutoSize = true;
            this.SecondNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondNumberLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.SecondNumberLabel.Location = new System.Drawing.Point(67, 156);
            this.SecondNumberLabel.Name = "SecondNumberLabel";
            this.SecondNumberLabel.Size = new System.Drawing.Size(209, 31);
            this.SecondNumberLabel.TabIndex = 5;
            this.SecondNumberLabel.Text = "Second Number";
            this.SecondNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SecondNumberTextBox
            // 
            this.SecondNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondNumberTextBox.Location = new System.Drawing.Point(275, 159);
            this.SecondNumberTextBox.Name = "SecondNumberTextBox";
            this.SecondNumberTextBox.Size = new System.Drawing.Size(426, 31);
            this.SecondNumberTextBox.TabIndex = 6;
            this.SecondNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AddButton
            // 
            this.AddButton.AutoSize = true;
            this.AddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.Location = new System.Drawing.Point(435, 246);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(118, 43);
            this.AddButton.TabIndex = 7;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.AutoSize = true;
            this.ResetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.Location = new System.Drawing.Point(298, 312);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(118, 43);
            this.ResetButton.TabIndex = 8;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // MultiplyButton
            // 
            this.MultiplyButton.AutoSize = true;
            this.MultiplyButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultiplyButton.Location = new System.Drawing.Point(158, 246);
            this.MultiplyButton.Name = "MultiplyButton";
            this.MultiplyButton.Size = new System.Drawing.Size(118, 43);
            this.MultiplyButton.TabIndex = 9;
            this.MultiplyButton.Text = "Multiply";
            this.MultiplyButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MultiplyButton.UseVisualStyleBackColor = true;
            this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // ResultsLabel
            // 
            this.ResultsLabel.AutoSize = true;
            this.ResultsLabel.BackColor = System.Drawing.Color.Transparent;
            this.ResultsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResultsLabel.Location = new System.Drawing.Point(68, 388);
            this.ResultsLabel.Name = "ResultsLabel";
            this.ResultsLabel.Size = new System.Drawing.Size(0, 29);
            this.ResultsLabel.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ResultsLabel);
            this.Controls.Add(this.MultiplyButton);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.SecondNumberTextBox);
            this.Controls.Add(this.SecondNumberLabel);
            this.Controls.Add(this.SimpleCalculatorLabel);
            this.Controls.Add(this.FirstNumberTextBox);
            this.Controls.Add(this.FirstNumberLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FirstNumberLabel;
        private System.Windows.Forms.TextBox FirstNumberTextBox;
        private System.Windows.Forms.Label CongratulationsLabel;
        private System.Windows.Forms.Label SimpleCalculatorLabel;
        private System.Windows.Forms.Label SecondNumberLabel;
        private System.Windows.Forms.TextBox SecondNumberTextBox;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button MultiplyButton;
        private System.Windows.Forms.Label ResultsLabel;
    }
}

